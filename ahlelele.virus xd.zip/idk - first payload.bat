@echo off
start brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborderstart brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborder
start brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborder
start brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborder
start brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborder
start brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborder
start brave https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB -windowed -noborder
start cmd.exe
start cmd.exe
start cmd.exe
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
wait 10
color a
dir/s
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"

echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"

echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
echo "polska gurom"
start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB
start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB
start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start brave.exe https://youtube.com/shorts/t9qMuJIO7GM?si=E_c89UhQWJLPQLmB 

start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe
start cmd.exe


